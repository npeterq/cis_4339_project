# Data Platform Project Setup

Requirements:

This project uses NodeJS and MongoDB.

## Backend Node Application
```
cd backend
```
Follow instructions in backend README

## Frontend Vue 3 Application
```
cd frontend
```
Follow instructions in frontend README

## Project 41 instructions
'''
mongodb atlas connection string: MONGO_URL = mongodb+srv://admin:Admin123!@cluster0.a6f0qsx.mongodb.net/test
'''
